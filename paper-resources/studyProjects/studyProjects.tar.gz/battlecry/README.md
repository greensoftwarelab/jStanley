
# commands for maven version
- run: mvn exec:java -Dexec.mainClass="bcry.battlecry" -Dexec.args="-t"

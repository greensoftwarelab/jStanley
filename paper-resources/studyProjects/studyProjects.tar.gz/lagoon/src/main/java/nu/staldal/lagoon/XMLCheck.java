package nu.staldal.lagoon;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;

import javax.xml.parsers.*;
import org.xml.sax.*;


/**
 * Small application to check for errors in XML files.
 * Can be invoked as a "compiler" from an editor such as Emacs
 * to automatically point out error locations in the XML file.
 *
 * Accepts either a local file name or an URL on the command line.
 */
public class XMLCheck
{
	public static void main(String[] args) 
		throws ParserConfigurationException, SAXException
	{
		boolean validate = false;
		String input = null;

		for (int i = 0; i<args.length; i++)
		{
			if (args[i].equals("-v"))
				validate = true;
			else
				input = args[i];
		}

		if (input == null)
		{
			System.out.println("Syntax: XMLCheck [-v] <filename or URL>");
			return;
		}

		MyParser parser = new MyParser();

		if (parser.parse(input, validate))
			System.exit(0);
		else
			System.exit(1);
	}
}

class MyParser implements ErrorHandler
{
	private boolean ioError;

	MyParser() {}

	boolean parse(String input, boolean validate) 
		throws ParserConfigurationException, SAXException
	{		
		XMLReader parser = 
			SAXParserFactory.newInstance().newSAXParser().getXMLReader(); 

        if (validate)
        {
    		try {
				parser.setFeature("http://xml.org/sax/features/validation", 
					true);
		    }
    		catch (SAXException e)
	    	{
		    	System.err.println("Unable to turn on validation: " + 
			    	e.getMessage());
    		}
		}

		parser.setErrorHandler(this);

		try {
			InputSource is = new InputSource(input);

			ioError = false;

			parser.parse(is);
		}
		catch (java.io.FileNotFoundException e)
		{
			System.err.println("File not found: " + e.getMessage());
			return false;
		}
		catch (java.io.IOException e)
		{
			System.err.println(e.toString());
			return false;
		}
		catch (SAXException e)
		{
			if (!ioError) System.err.println("Document not well-formed");
			return false;
		}
		return true;
	}

	public void warning(SAXParseException e)
	{
		try {
			String name = (e.getSystemId() == null)
				? null 
				: ((e.getSystemId().startsWith("file:")) 
					? new File(new URI(e.getSystemId())).toString()
					: e.getSystemId());
					
			System.err.println(name + ":" + e.getLineNumber() + ":"
				+ e.getColumnNumber() + ": Warning: " + e.getMessage());
		}
		catch (URISyntaxException ex)
		{
			ex.printStackTrace(System.err);	
		}
	}

	public void error(SAXParseException e)
	{
		try {
			String name = (e.getSystemId() == null)
				? null 
				: ((e.getSystemId().startsWith("file:")) 
					? new File(new URI(e.getSystemId())).toString()
					: e.getSystemId());
	
			System.err.println(name + ":" + e.getLineNumber() + ":"
				+ e.getColumnNumber() + ": Error: " + e.getMessage());
		}
		catch (URISyntaxException ex)
		{
			ex.printStackTrace(System.err);	
		}
	}

	public void fatalError(SAXParseException e)
	{
		try {
			String name = (e.getSystemId() == null)
				? null 
				: ((e.getSystemId().startsWith("file:")) 
					? new File(new URI(e.getSystemId())).toString()
					: e.getSystemId());
	
			if (name == null)
			{
				System.err.println(e.getMessage());
				ioError = true;
			}
			else
			{
				System.err.println(name + ":" + e.getLineNumber() + ":"
					+ e.getColumnNumber() +  ": Fatal: " + e.getMessage());
			}
		}
		catch (URISyntaxException ex)
		{
			ex.printStackTrace(System.err);	
		}
	}
}

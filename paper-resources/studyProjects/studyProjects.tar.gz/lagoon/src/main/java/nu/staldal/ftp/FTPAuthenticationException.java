package nu.staldal.ftp;


public class FTPAuthenticationException extends FTPException
{
	public FTPAuthenticationException()
	{
		super("Invalid password");
	}

}


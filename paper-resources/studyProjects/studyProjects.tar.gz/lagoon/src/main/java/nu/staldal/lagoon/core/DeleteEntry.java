package nu.staldal.lagoon.core;

import java.io.*;


/**
 * An entry in the sitemap to delete a file in the target.
 *
 * @see nu.staldal.lagoon.core.Sitemap
 */
class DeleteEntry implements SitemapEntry
{
    private static final boolean DEBUG = false;

	private final LagoonProcessor processor;

    private final String targetURL;

    /**
     * Constructor.
     *
     * @param targetURL  the file to create, may contain wildcard anywhere,
     *                   must be pseudo-absolute.
     * @param targetStorage  where to store generated files
     */
    public DeleteEntry(LagoonProcessor processor, String targetURL)
    {
		this.processor = processor;
        this.targetURL = targetURL;
    }


    public void destroy()
        throws IOException
    {
        // nothing to do
    }
            

    public void beforeBuild(boolean always)
        throws IOException
    {
        // nothing to do
    }
    
    
    public boolean build(boolean always)
        throws IOException
    {
		processor.log.println("Deleting: " + targetURL);

	    processor.getTargetLocation().deleteFile(targetURL);
		
		return true;
    }


    public void afterBuild(boolean always)
        throws IOException
    {
        // nothing to do
    }
	
}


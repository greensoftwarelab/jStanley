package net.sourceforge.barbecue.linear;

import junit.framework.TestCase;

import java.awt.*;
import java.awt.font.TextLayout;

import net.sourceforge.barbecue.BarcodeException;
import net.sourceforge.barbecue.Module;
import net.sourceforge.barbecue.BlankModule;
import net.sourceforge.barbecue.GraphicsMock;
import net.sourceforge.barbecue.env.DefaultEnvironment;
import net.sourceforge.barbecue.output.GraphicsOutput;
import net.sourceforge.barbecue.output.Output;
import net.sourceforge.barbecue.output.OutputException;
import net.sourceforge.barbecue.output.CenteredLabelLayout;

public class LinearBarcodeTest extends TestCase {

	public void testDrawMakesCorrectCallbacksForDefaultMode() throws Exception {
		BarcodeMock barcode = new BarcodeMock("12345");
		barcode.draw(new GraphicsOutput(new GraphicsMock(), null, Color.black, Color.white), 0, 0, 1, 50);
		assertTrue(barcode.isCalculatedCheckDigit());
		assertTrue(barcode.isEncodedData());
		assertTrue(barcode.isGotPostamble());
		assertTrue(barcode.isGotPreamble());
	}

	public class TextOnlyBarcode extends LinearBarcode {
		private boolean textDrawn;

		public TextOnlyBarcode(String data) throws BarcodeException {
			super(data);
		}

		protected Module calculateChecksum() {
			return null;
		}

		protected Module[] encodeData() {
			return new Module[0];
		}

		protected Module getPostAmble() {
			return null;
		}

		protected Module getPreAmble() {
			return null;
		}

		protected int drawTextLabel(Output params, int x, int y, int width) throws OutputException {
			textDrawn = true;
			return super.drawTextLabel(params, x, y, width);
		}
	}

	public class BarcodeMock extends LinearBarcode {
		private boolean encodedData = false;
		private boolean calculatedCheckDigit = false;
		private boolean gotPreamble = false;
		private boolean gotPostamble = false;

		public BarcodeMock(String data) throws BarcodeException {
			this(data, true);
		}

		public BarcodeMock(String data, boolean drawText) throws BarcodeException {
			super(data);
			drawingText = drawText;
		}

		protected double getBarcodeWidth(int resolution) {
			return 0;
		}

		protected Module[] encodeData() {
			encodedData = true;
			return new Module[] {new Module( new int[] {2, 1, 1, 2, 4} )};
		}

		protected Module calculateChecksum() {
			calculatedCheckDigit = true;
			return new BlankModule(0);
		}

		protected Module getPreAmble() {
			gotPreamble = true;
			return new BlankModule(0);
		}

		protected Module getPostAmble() {
			gotPostamble = true;
			return new BlankModule(0);
		}

		public boolean isEncodedData() {
			return encodedData;
		}

		public boolean isCalculatedCheckDigit() {
			return calculatedCheckDigit;
		}

		public boolean isGotPreamble() {
			return gotPreamble;
		}

		public boolean isGotPostamble() {
			return gotPostamble;
		}
	}
}
